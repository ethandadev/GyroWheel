@echo off
echo Installing requirements...
pip install -r requirements.txt
pip install pyinstaller

echo Building executable...
pyinstaller --onefile --noconsole --name "GyroWheel_Receiver" receiver.py

echo Done! The executable is located in the 'dist' folder.
pause
